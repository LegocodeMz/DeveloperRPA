from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import os
from datetime import datetime
from pathlib import Path

class Initiation:
    
    def __init__(self):
        
         #Iniciar o browser
        self.driver = webdriver.Chrome()
        self.driver.maximize_window()

        self.log_dir = "logs"
        os.makedirs(self.log_dir, exist_ok=True)
        self.download_dir = os.path.join(os.getcwd(), "download")

        current_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self.log_file = os.path.join(self.log_dir, f"log_{current_time}.txt")
        
       

    def log(self, message):
        #Digitar as mensagem no log (formato txt)
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(message + "\n")
        print(message)
        
    def opensitelogin(self):
        try:
            self.log("Iniciando o processo")

            self.driver.get("https://rpa.xidondzo.com/")
            time.sleep(2)
            self.log("Website acessado com sucesso")

        except Exception as e:
            self.log(f"Erro em acessar o Website: {e}")

            
    def downloadfile(self):
        try:
            self.log("Acessando o ficheiro por descarregar")

            self.driver.find_element(By.XPATH,"/html/body/section/div[2]")
            self.log("Localizado")
            self.driver.find_element(By.XPATH,"/html/body/section/div[2]/div[2]")
            self.log("Tabela localizada")
            self.driver.find_element(By.XPATH,"/html/body/section/div[2]/div[2]/div/div/table/tbody/tr[1]/td[6]/a")
            
            self.log("Botao localizado")
            #if Descarregar.is_displayed():
            self.log("Botao localizado e preste a clicar")
            Descarregar = self.driver.find_element(By.XPATH, "/html/body/section/div[2]/div[2]/div/div/table/tbody/tr[1]/td[6]/a")
            Descarregar.click()
            self.log("Botao localizado e clicado")
            #time(5)

        except Exception as e:
            self.log(f"Erro ao descarregar o ficheiro: {e}")
            time.sleep(2)
            
    def identificar_ficheiro_extrair_dados(self): 
        try:
            self.log("Acessando o ficheiro por descarregar")

            # Localiza a tabela
            tabela = self.driver.find_element(By.XPATH, "/html/body/section/div[2]/div[2]/div/div/table/tbody")
            linhas = tabela.find_elements(By.TAG_NAME, "tr")

            self.log(f"Foram encontradas {len(linhas)} linhas na tabela.")


            for i, linha in enumerate(linhas, start=1):
                try:
                    self.log(f"Processando linha {i}...")

  
                    colunas = linha.find_elements(By.TAG_NAME, "td")
                    dados = [coluna.text for coluna in colunas]
                    self.log(f"Dados da linha {i}: {dados}")


                    botao = linha.find_element(By.XPATH, f"./td[6]/a")
                    self.log(f"Botão 'Descarregar' encontrado na linha {i}. Clicando...")

                    botao.click()
                    self.log(f"Download iniciado para a linha {i}.")

         
                    time.sleep(2)

                except Exception as e:
                    self.log(f"Erro ao processar a linha {i}: {e}")
                continue

            self.log("Processo de download concluído com sucesso!")

        except Exception as e:
            self.log(f"Erro geral ao descarregar os ficheiros: {e}")
            time.sleep(2)
        
    
    #Abrir, verificar e extrair: nNome, Email, Contacto, estado Civil, salario Liquido
    
    def verificacao_extracao(self,ficheiro_txt):
        try:
            
            nome_ficheiro = ""

            with open(nome_ficheiro, "w", encoding="utf-8") as ficheiro:

                for registo in nome_ficheiro:
    
                    linha = (
                        f"Nome: {registo['nome']}, " 
                        f"Email: {registo['email']}, "
                        f"Contacto: {registo['contacto']}, "
                        f"Estado Civil: {registo['estado_civil']}, "
                        f"Salário Líquido: {registo['salario_liquido']}\n"
                    )
                   
                    ficheiro.write(linha)

                    print(f"Dados extraídos para o ficheiro {nome_ficheiro}")
             
        except Exception as e:
            self.log(f"Erro na verificao e extracao de dados{e}")
        time.sleep(2)
        
            
        
    def run(self):
        self.opensitelogin()
        self.downloadfile()
        self.identificar_ficheiro_extrair_dados()
        #self.verificacao_extracao()

              
        
reading = Initiation()
reading.run()
    
    