using System;
using System.IO;

namespace NBK_RPA_CS.Config
{
    public class ConfigService
    {
        public string StartUrl { get; private set; } = "https://rap.xidondzo.com/";
        public string LogsPath { get; private set; } = "Logs/log.txt";
        public string ExportsPath { get; private set; } = "Exports";
        public int DownloadWaitSeconds { get; private set; } = 20;

        public ConfigService()
        {
            // Cria apenas o diretório, não o arquivo
            var logsDir = Path.GetDirectoryName(LogsPath) ?? "Logs";
            Directory.CreateDirectory(logsDir);

            Directory.CreateDirectory(ExportsPath);
        }
    }
}
