using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.IO;

namespace NBK_RPA_CS.Factories
{
    public static class WebDriverFactory
    {
        // Creates ChromeDriver configured to download files automatically to the given folder
        public static IWebDriver CreateChromeDriver(string downloadDirectory, bool headless = true)
        {
            var options = new ChromeOptions();
            if (headless) options.AddArgument("--headless=new");
            options.AddArgument("--no-sandbox");
            options.AddArgument("--disable-dev-shm-usage");
            options.AddArgument("--disable-gpu");

            // Disable password leak popup and password manager
            options.AddArgument("--disable-features=PasswordLeakDetection,PasswordManagerOnboarding,PasswordManagerSettingsRework");
            options.AddUserProfilePreference("credentials_enable_service", false);
            options.AddUserProfilePreference("profile.password_manager_enabled", false);

            // Set download directory
            Directory.CreateDirectory(downloadDirectory);
            options.AddUserProfilePreference("download.prompt_for_download", false);
            options.AddUserProfilePreference("download.default_directory", Path.GetFullPath(downloadDirectory));
            options.AddUserProfilePreference("profile.default_content_settings.popups", 0);

            return new ChromeDriver(options);
        }
    }
}
