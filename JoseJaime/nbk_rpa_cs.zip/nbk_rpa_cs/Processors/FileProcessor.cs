using System.Collections.Generic;
using NBK_RPA_CS.Services; // 🔑 Referência ao LoggerService
using NBK_RPA_CS.Processors;

namespace NBK_RPA_CS.Processors
{
    public class FileProcessor
    {
        private readonly LoggerService _logger;

        public FileProcessor(LoggerService logger)
        {
            _logger = logger;
        }

        public List<Record> ProcessFile(string filePath)
        {
            _logger.Info($"Processing file: {filePath}");

            // Exemplo: cria registros fictícios
            return new List<Record>
            {
                new Record { Name = "Test", Value = "123" }
            };
        }
    }
}
