public class Record
{
    public string Name { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
}

public class NormalizedRecord
{
    public string Name { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
}
