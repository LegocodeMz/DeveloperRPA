using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using CsvHelper;

namespace NBK_RPA_CS.Services
{
    public class ExportService
    {
        private readonly LoggerService _logger;

        public ExportService(LoggerService logger)
        {
            _logger = logger;
        }

        public string ExportNormalized(IEnumerable<NormalizedRecord> records)
        {
            string outPath = Path.Combine(Path.GetTempPath(), "normalized.csv");
            using var writer = new StreamWriter(outPath);
            writer.WriteLine("Name,Value");
            foreach (var r in records)
            {
                writer.WriteLine($"{r.Name},{r.Value}");
            }
            _logger.Info($"Exported {records.Count()} records to {outPath}");
            return outPath;
        }
    }
}
